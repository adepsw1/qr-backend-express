// Simple entry point for Hostinger
require('./src/index.js');
